/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author ASUS - Achmad gez de lopez al karim - 19201294
 */
public class CalculatorController implements Initializable {

    @FXML
    private TextArea display;
    @FXML
    private Button tiga;
    @FXML
    private Button satu;
    @FXML
    private Button dua;
    @FXML
    private Button kali;
    @FXML
    private Button lima;
    @FXML
    private Button tambah;
    @FXML
    private Button kurang;
    @FXML
    private Button nol;
    @FXML
    private Button empat;
    @FXML
    private Button enam;
    @FXML
    private Button tujuh;
    @FXML
    private Button delapan;
    @FXML
    private Button sembilan;
    @FXML
    private Button bagi;
    @FXML
    private Button fix;
    @FXML
    private Button hapus;
    private int angka1 = 0;
    private String operasi = "netral";
    private int angka2 = 0;
    private int hasil;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void buttonClicked(ActionEvent event) {
    if(event.getSource()== nol ){
          if(!display.getText().isBlank()){
                display.setText(display.getText() + "0");
          }
    }
    if(event.getSource()== satu ){
            display.setText(display.getText() + "1" );
    }
    else if(event.getSource()== dua ){
            display.setText(display.getText() + "2");
    }      
    else if(event.getSource()== tiga ){
            display.setText(display.getText() + "3" );
    } 
    else if(event.getSource()== empat ){
            display.setText(display.getText() + "4");
    }      
    else if(event.getSource()== lima ){
            display.setText(display.getText() + "5" );
    }        
    else if(event.getSource()== enam ){
            display.setText(display.getText() + "6");
    }      
    else if(event.getSource()== tujuh ){
            display.setText(display.getText() + "7" );
    }
    else if(event.getSource()== delapan ){
            display.setText(display.getText() + "8");
    }     
    else if(event.getSource()== sembilan ){
            display.setText(display.getText() + "9" );
    }          
    else if (event.getSource() == hapus) {
            display.setText("");
    }        
    else if (event.getSource() == tambah) {
        angka1 = Integer.parseInt(display.getText());
        operasi = "plus";
        display.setText("");
    }    
    else if (event.getSource() == kurang) {
        angka1 = Integer.parseInt(display.getText());
        operasi = "minus";
        display.setText("");
    }    
    else if (event.getSource() == kali) {
        angka1 = Integer.parseInt(display.getText());
        operasi = "kali";
        display.setText("");
    }   
    else if (event.getSource() == bagi) {
        angka2 = Integer.parseInt(display.getText());
    }
    else if (event.getSource() == fix) {
        angka2 = Integer.parseInt(display.getText());
    }   
        if (operasi.equals("tambah")) {
        hasil = angka1 + angka2;
    }
        if (operasi.equals("kurang")) {
        hasil = angka1 - angka2;
    }
        if (operasi.equals("kali")) {
        hasil = angka1 * angka2;
    }
        display.setText(String.valueOf(hasil));
        operasi = "netral";
    }
  }
